const User = require("../models/User");
const Division = require("../models/Division");

const bcrypt = require("bcryptjs");

const generateToken = require("../utils/generateToken");

// =====================================================
// REGISTER USER
// Public registration always creates STUDENT
// =====================================================

const registerUser = async (req, res) => {
  try {
    const {
      name,
      email,
      password,
    } = req.body;

    if (
      !name ||
      !email ||
      !password
    ) {
      return res.status(400).json({
        message:
          "Name, email and password are required",
      });
    }

    const cleanEmail =
      email.toLowerCase().trim();

    // Check existing user
    const existingUser =
      await User.findOne({
        email: cleanEmail,
      });

    if (existingUser) {
      return res.status(400).json({
        message:
          "User with this email already exists",
      });
    }

    // Password validation
    if (password.length < 6) {
      return res.status(400).json({
        message:
          "Password must be at least 6 characters",
      });
    }

    // Hash password
    const hashedPassword =
      await bcrypt.hash(
        password,
        10
      );

    // Public registration = STUDENT
    const user = await User.create({
      name: name.trim(),
      email: cleanEmail,
      password: hashedPassword,
      role: "STUDENT",
      division: null,
    });

    const token = generateToken(
      user._id,
      user.role
    );

    return res.status(201).json({
      message:
        "Registration successful",

      token,

      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        division: user.division,
      },
    });

  } catch (error) {
    console.error(
      "REGISTRATION ERROR:",
      error
    );

    return res.status(500).json({
      message:
        "Registration failed",
      error: error.message,
    });
  }
};

// =====================================================
// LOGIN USER
// =====================================================

const loginUser = async (req, res) => {
  try {
    const {
      email,
      password,
    } = req.body;

    if (
      !email ||
      !password
    ) {
      return res.status(400).json({
        message:
          "Email and password are required",
      });
    }

    const cleanEmail =
      email.toLowerCase().trim();

    const user =
      await User.findOne({
        email: cleanEmail,
      });

    if (!user) {
      return res.status(401).json({
        message:
          "Invalid email or password",
      });
    }

    const passwordMatches =
      await bcrypt.compare(
        password,
        user.password
      );

    if (!passwordMatches) {
      return res.status(401).json({
        message:
          "Invalid email or password",
      });
    }

    const token = generateToken(
      user._id,
      user.role
    );

    return res.status(200).json({
      message:
        "Login successful",

      token,

      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        division: user.division,
      },
    });

  } catch (error) {
    console.error(
      "LOGIN ERROR:",
      error
    );

    return res.status(500).json({
      message:
        "Login failed",
      error: error.message,
    });
  }
};

// =====================================================
// ASSIGN STUDENT TO DIVISION
// ADMIN ONLY
// =====================================================

const assignStudentDivision = async (
  req,
  res
) => {
  try {
    const {
      studentId,
      divisionId,
    } = req.body;

    if (
      !studentId ||
      !divisionId
    ) {
      return res.status(400).json({
        message:
          "Student ID and division ID are required",
      });
    }

    const student =
      await User.findById(studentId);

    if (!student) {
      return res.status(404).json({
        message:
          "Student not found",
      });
    }

    if (
      student.role !== "STUDENT"
    ) {
      return res.status(400).json({
        message:
          "Selected user is not a student",
      });
    }

    const division =
      await Division.findById(
        divisionId
      );

    if (!division) {
      return res.status(404).json({
        message:
          "Division not found",
      });
    }

    student.division =
      division._id;

    await student.save();

    return res.status(200).json({
      message:
        "Student division assigned successfully",

      user: {
        id: student._id,
        name: student.name,
        email: student.email,
        role: student.role,
        division: student.division,
      },
    });

  } catch (error) {
    console.error(
      "ASSIGN DIVISION ERROR:",
      error
    );

    return res.status(500).json({
      message:
        "Failed to assign student division",
      error: error.message,
    });
  }
};

module.exports = {
  registerUser,
  loginUser,
  assignStudentDivision,
};