const MasterTimetable = require("../models/MasterTimetable");
const Department = require("../models/Department");
const Semester = require("../models/Semester");
const Batch = require("../models/Batch");

const {
  generateMasterTimetable,
} = require("../services/masterTimetableGenerator");

const getMasterTimetables =
  async (req, res) => {
    try {
      const timetables =
        await MasterTimetable.find()
          .populate(
            "department",
            "name code"
          )
          .populate(
            "semesters",
            "name number"
          )
          .sort({
            createdAt: -1,
          });

      res.json({
        timetables,
      });
    } catch (error) {
      res.status(500).json({
        message:
          "Failed to fetch master timetables.",
        error: error.message,
      });
    }
  };

const getMasterTimetableById =
  async (req, res) => {
    try {
      const timetable =
        await MasterTimetable.findById(
          req.params.id
        )
          .populate(
            "department",
            "name code"
          )
          .populate(
            "semesters",
            "name number"
          )
          .populate(
            "entries.semester",
            "name number"
          )
          .populate(
            "entries.batch",
            "name code studentCount startRoll endRoll"
          )
          .populate(
            "entries.subject",
            "name code type"
          )
          .populate(
            "entries.faculty",
            "name employeeId"
          )
          .populate(
            "entries.room",
            "name roomNumber type"
          )
          .populate(
            "entries.timeSlot"
          );

      if (!timetable) {
        return res.status(404).json({
          message:
            "Master timetable not found.",
        });
      }

      res.json({
        timetable,
      });
    } catch (error) {
      res.status(500).json({
        message:
          "Failed to fetch master timetable.",
        error: error.message,
      });
    }
  };

const generateMaster =
  async (req, res) => {
    try {
      const {
        department,
      } = req.body;

      if (!department) {
        return res.status(400).json({
          message:
            "Department is required.",
        });
      }

      const departmentData =
        await Department.findById(
          department
        );

      if (!departmentData) {
        return res.status(404).json({
          message:
            "Department not found.",
        });
      }

      const result =
        await generateMasterTimetable({
          departmentId:
            department,
        });

      const master =
        await MasterTimetable.create({
          department,
          academicYear: "2025-26",
          semesters:
            result.semesters.map(
              (semester) =>
                semester._id
            ),
          entries:
            result.entries,
          status: "GENERATED",
          generatedBy:
            req.user?._id || null,
        });

      const populated =
        await MasterTimetable.findById(
          master._id
        )
          .populate(
            "department",
            "name code"
          )
          .populate(
            "semesters",
            "name number"
          )
          .populate(
            "entries.semester",
            "name number"
          )
          .populate(
            "entries.batch",
            "name code studentCount startRoll endRoll"
          )
          .populate(
            "entries.subject",
            "name code type"
          )
          .populate(
            "entries.faculty",
            "name employeeId"
          )
          .populate(
            "entries.room",
            "name roomNumber type"
          )
          .populate(
            "entries.timeSlot"
          );

      res.status(201).json({
        message:
          "CSE master timetable generated successfully.",
        timetable:
          populated,
      });
    } catch (error) {
      console.error(
        "MASTER TIMETABLE ERROR:",
        error
      );

      res.status(500).json({
        message:
          error.message ||
          "Failed to generate master timetable.",
      });
    }
  };

const getBatches =
  async (req, res) => {
    try {
      const {
        semester,
      } = req.query;

      const filter = {
        isActive: true,
      };

      if (semester) {
        filter.semester =
          semester;
      }

      const batches =
        await Batch.find(filter)
          .populate(
            "semester",
            "name number"
          )
          .sort({
            startRoll: 1,
          });

      res.json({
        batches,
      });
    } catch (error) {
      res.status(500).json({
        message:
          "Failed to fetch batches.",
        error: error.message,
      });
    }
  };

module.exports = {
  getMasterTimetables,
  getMasterTimetableById,
  generateMaster,
  getBatches,
};