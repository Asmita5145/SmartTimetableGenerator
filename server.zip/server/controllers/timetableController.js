const Timetable = require("../models/Timetable");
const Division = require("../models/Division");
const Department = require("../models/Department");
const Semester = require("../models/Semester");
const Subject = require("../models/Subject");
const Faculty = require("../models/Faculty");
const Room = require("../models/Room");
const TimeSlot = require("../models/TimeSlot");

const {
  validateTimetable
} = require("../services/timetableValidator");

const {
  generateTimetable
} = require("../services/timetableGenerator");


// =====================================================
// CREATE TIMETABLE
// =====================================================

const createTimetable = async (req, res) => {
  try {
    const {
      department,
      semester,
      division,
      entries,
      status
    } = req.body;

    if (!department || !semester) {
      return res.status(400).json({
        message:
          "Department and semester are required"
      });
    }

    const timetable = await Timetable.create({
      department,
      semester,
      division: division || null,
      entries: entries || [],
      status: status || "DRAFT",
      generatedBy: req.user._id
    });

    res.status(201).json({
      message: "Timetable created successfully",
      timetable
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to create timetable",
      error: error.message
    });
  }
};


// =====================================================
// GET ALL TIMETABLES
// =====================================================

const getTimetables = async (req, res) => {
  try {
    const timetables = await Timetable.find()
      .populate("department", "name code")
      .populate("semester", "name number")
      .populate("division", "name studentCount")
      .populate("generatedBy", "name email")
      .sort({ createdAt: -1 });

    res.status(200).json({
      message: "Timetables fetched successfully",
      timetables
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to fetch timetables",
      error: error.message
    });
  }
};


// =====================================================
// GET TIMETABLE BY ID
// =====================================================

const getTimetableById = async (req, res) => {
  try {
    const timetable = await Timetable.findById(req.params.id)
      .populate("department", "name code")
      .populate("semester", "name number")
      .populate("division", "name studentCount")
      .populate("entries.subject", "name code type")
      .populate("entries.faculty", "name employeeId")
      .populate("entries.room", "name roomNumber type")
      .populate(
        "entries.timeSlot",
        "day startTime endTime slotNumber isBreak"
      )
      .populate("generatedBy", "name email");

    if (!timetable) {
      return res.status(404).json({
        message: "Timetable not found"
      });
    }

    res.status(200).json({
      message: "Timetable fetched successfully",
      timetable
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to fetch timetable",
      error: error.message
    });
  }
};


// =====================================================
// UPDATE TIMETABLE
// =====================================================

const updateTimetable = async (req, res) => {
  try {
    const timetable = await Timetable.findById(
      req.params.id
    );

    if (!timetable) {
      return res.status(404).json({
        message: "Timetable not found"
      });
    }

    const {
      department,
      semester,
      division,
      entries,
      status
    } = req.body;

    timetable.department =
      department || timetable.department;

    timetable.semester =
      semester || timetable.semester;

    if (division !== undefined) {
      timetable.division = division || null;
    }

    timetable.entries =
      entries || timetable.entries;

    timetable.status =
      status || timetable.status;

    await timetable.save();

    res.status(200).json({
      message: "Timetable updated successfully",
      timetable
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to update timetable",
      error: error.message
    });
  }
};

// =====================================================
// EDIT SINGLE TIMETABLE ENTRY
// =====================================================

const updateTimetableEntry = async (req, res) => {
  try {
    const { id, entryId } = req.params;

    const {
      timeSlot,
      faculty,
      room
    } = req.body;

    // ---------------------------------------------
    // Find timetable
    // ---------------------------------------------

    const timetable = await Timetable.findById(id);

    if (!timetable) {
      return res.status(404).json({
        message: "Timetable not found"
      });
    }

    // ---------------------------------------------
    // Find timetable entry
    // ---------------------------------------------

    const entry = timetable.entries.id(entryId);

    if (!entry) {
      return res.status(404).json({
        message: "Timetable entry not found"
      });
    }

    // ---------------------------------------------
    // Validate provided TimeSlot
    // ---------------------------------------------

    if (timeSlot) {
      const selectedTimeSlot =
        await TimeSlot.findById(timeSlot);

      if (!selectedTimeSlot) {
        return res.status(404).json({
          message: "Selected time slot not found"
        });
      }

      if (selectedTimeSlot.isBreak) {
        return res.status(400).json({
          message:
            "A timetable entry cannot be assigned to a break slot"
        });
      }

      entry.timeSlot = timeSlot;
    }

    // ---------------------------------------------
    // Validate provided Faculty
    // ---------------------------------------------

    if (faculty) {
      const selectedFaculty =
        await Faculty.findById(faculty);

      if (!selectedFaculty) {
        return res.status(404).json({
          message: "Selected faculty not found"
        });
      }

      entry.faculty = faculty;
    }

    // ---------------------------------------------
    // Validate provided Room
    // ---------------------------------------------

    if (room) {
      const selectedRoom =
        await Room.findById(room);

      if (!selectedRoom) {
        return res.status(404).json({
          message: "Selected room not found"
        });
      }

      entry.room = room;
    }

    // ---------------------------------------------
    // Validate the modified timetable
    // ---------------------------------------------

    const validationResult =
      await validateTimetable(timetable);

    if (!validationResult.isValid) {
      return res.status(400).json({
        message:
          "Timetable entry cannot be updated because it creates conflicts",
        result: validationResult
      });
    }

    // ---------------------------------------------
    // Any manual edit creates a DRAFT
    // ---------------------------------------------

    timetable.status = "DRAFT";

    await timetable.save();

    // ---------------------------------------------
    // Fetch updated timetable with populated data
    // ---------------------------------------------

    const updatedTimetable =
      await Timetable.findById(timetable._id)
        .populate("department", "name code")
        .populate("semester", "name number")
        .populate("division", "name studentCount")
        .populate("entries.subject", "name code type")
        .populate("entries.faculty", "name employeeId")
        .populate(
          "entries.room",
          "name roomNumber type capacity"
        )
        .populate(
          "entries.timeSlot",
          "day startTime endTime slotNumber isBreak"
        )
        .populate("generatedBy", "name email");

    res.status(200).json({
      message:
        "Timetable entry updated successfully. Timetable moved to DRAFT.",
      timetable: updatedTimetable,
      result: validationResult
    });

  } catch (error) {
    console.error(
      "Update timetable entry error:",
      error
    );

    res.status(500).json({
      message:
        "Failed to update timetable entry",
      error: error.message
    });
  }
};

// =====================================================
// DELETE TIMETABLE
// =====================================================

const deleteTimetable = async (req, res) => {
  try {
    const timetable = await Timetable.findById(
      req.params.id
    );

    if (!timetable) {
      return res.status(404).json({
        message: "Timetable not found"
      });
    }

    await timetable.deleteOne();

    res.status(200).json({
      message: "Timetable deleted successfully"
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to delete timetable",
      error: error.message
    });
  }
};


// =====================================================
// VALIDATE TIMETABLE
// =====================================================

const validateTimetableById = async (req, res) => {
  try {
    const timetable = await Timetable.findById(
      req.params.id
    )
      .populate("division")
      .populate("entries.subject")
      .populate("entries.faculty")
      .populate("entries.room")
      .populate("entries.timeSlot");

    if (!timetable) {
      return res.status(404).json({
        message: "Timetable not found"
      });
    }

    const result = await validateTimetable(
      timetable
    );

    res.status(200).json({
      message: "Timetable validation completed",
      result
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to validate timetable",
      error: error.message
    });
  }
};


// =====================================================
// PUBLISH TIMETABLE
// =====================================================

const publishTimetable = async (req, res) => {
  try {
    const timetable = await Timetable.findById(
      req.params.id
    )
      .populate("division")
      .populate("entries.subject")
      .populate("entries.faculty")
      .populate("entries.room")
      .populate("entries.timeSlot");

    if (!timetable) {
      return res.status(404).json({
        message: "Timetable not found"
      });
    }

    // Validate before publishing
    const validationResult =
      await validateTimetable(timetable);

    if (!validationResult.isValid) {
      return res.status(400).json({
        message:
          "Timetable cannot be published because validation failed",
        result: validationResult
      });
    }

    // Unpublish any previously published timetable
    // for the same department + semester + division.
    //
    // If division is null, this correctly targets
    // semester-level timetables.

    await Timetable.updateMany(
      {
        department: timetable.department._id,
        semester: timetable.semester._id,
        division: timetable.division
          ? timetable.division._id
          : null,
        status: "PUBLISHED",
        _id: {
          $ne: timetable._id
        }
      },
      {
        $set: {
          status: "DRAFT"
        }
      }
    );

    // Publish the selected timetable
    timetable.status = "PUBLISHED";

    await timetable.save();

    res.status(200).json({
      message:
        "Timetable validated and published successfully",
      timetable
    });

  } catch (error) {
    res.status(500).json({
      message: "Failed to publish timetable",
      error: error.message
    });
  }
};

// =====================================================
// GET MY TIMETABLE - STUDENT
// =====================================================

const getMyTimetable = async (req, res) => {
  try {
    // ---------------------------------------------
    // Check student role
    // ---------------------------------------------

    if (req.user.role !== "STUDENT") {
      return res.status(403).json({
        message: "Student access required"
      });
    }

    // ---------------------------------------------
    // Check division assignment
    // ---------------------------------------------


    if (!req.user.semester) {
      return res.status(400).json({
        message:
          "Your academic assignment is pending.",
        code:
          "ACADEMIC_ASSIGNMENT_PENDING"
      });
    }

    // ---------------------------------------------
    // Find published timetable
    // ---------------------------------------------

    let timetable;

    // -------------------------------------------------
    // FIRST: Try division timetable
    // -------------------------------------------------

    if (req.user.division) {
      timetable =
        await Timetable.findOne({
          division: req.user.division,
          status: "PUBLISHED"
        })
          .populate(
            "department",
            "name code"
          )
          .populate(
            "semester",
            "name number"
          )
          .populate(
            "division",
            "name studentCount"
          )
          .populate(
            "entries.subject",
            "name code type"
          )
          .populate(
            "entries.faculty",
            "name employeeId"
          )
          .populate(
            "entries.room",
            "name roomNumber type"
          )
          .populate(
            "entries.timeSlot",
            "day startTime endTime slotNumber isBreak"
          );
    }

    // -------------------------------------------------
    // SECOND: Try semester-level timetable
    // -------------------------------------------------

    if (
      !timetable &&
      req.user.semester
    ) {
      timetable =
        await Timetable.findOne({
          semester: req.user.semester,
          division: null,
          status: "PUBLISHED"
        })
          .populate(
            "department",
            "name code"
          )
          .populate(
            "semester",
            "name number"
          )
          .populate(
            "division",
            "name studentCount"
          )
          .populate(
            "entries.subject",
            "name code type"
          )
          .populate(
            "entries.faculty",
            "name employeeId"
          )
          .populate(
            "entries.room",
            "name roomNumber type"
          )
          .populate(
            "entries.timeSlot",
            "day startTime endTime slotNumber isBreak"
          );
    }

    // ---------------------------------------------
    // No timetable found
    // ---------------------------------------------

    if (!timetable) {
      return res.status(404).json({
        message:
          "No published timetable found for your academic assignment"
      });
    }

    // ---------------------------------------------
    // Fetch COMPLETE time-slot configuration
    // ---------------------------------------------

    const timeSlots = await TimeSlot.find({
      day: {
        $in: [
          "MONDAY",
          "TUESDAY",
          "WEDNESDAY",
          "THURSDAY",
          "FRIDAY"
        ]
      }
    }).sort({
      slotNumber: 1
    });

    // ---------------------------------------------
    // Return timetable + all time slots
    // ---------------------------------------------

    res.status(200).json({
      message:
        "Student timetable fetched successfully",

      timetable,

      timeSlots
    });

  } catch (error) {
    console.error(
      "Student timetable error:",
      error
    );

    res.status(500).json({
      message:
        "Failed to fetch student timetable",

      error: error.message
    });
  }
};

// =====================================================
// GENERATE TIMETABLE
// =====================================================

const generateTimetableByConfig = async (req, res) => {
  try {
    const {
      department,
      semester,
      division
    } = req.body;

    // -------------------------------------------------
    // Basic validation
    // -------------------------------------------------

    if (!department || !semester) {
      return res.status(400).json({
        message:
          "Department and semester are required."
      });
    }

    // -------------------------------------------------
    // Validate department
    // -------------------------------------------------

    const departmentData =
      await Department.findById(department);

    if (!departmentData) {
      return res.status(404).json({
        message: "Department not found."
      });
    }

    // -------------------------------------------------
    // Validate semester
    // -------------------------------------------------

    const semesterData =
      await Semester.findOne({
        _id: semester,
        department
      });

    if (!semesterData) {
      return res.status(400).json({
        message:
          "Selected semester does not belong to the selected department."
      });
    }

    // -------------------------------------------------
    // Optional division
    // -------------------------------------------------

    let divisionData = null;

    if (division) {
      divisionData =
        await Division.findOne({
          _id: division,
          semester
        });

      if (!divisionData) {
        return res.status(400).json({
          message:
            "Selected division does not belong to the selected semester."
        });
      }
    }

    // -------------------------------------------------
    // Find subjects
    // -------------------------------------------------

    const subjects =
      await Subject.find({
        department,
        semester
      })
        .populate(
          "faculty",
          "name employeeId email department"
        )
        .lean();

    if (!subjects.length) {
      return res.status(400).json({
        message:
          "No subjects found for the selected semester."
      });
    }

    // -------------------------------------------------
    // Find faculty
    // -------------------------------------------------

    const faculty =
      await Faculty.find({
        department
      }).lean();

    if (!faculty.length) {
      return res.status(400).json({
        message:
          "No faculty members found for this department."
      });
    }

    // -------------------------------------------------
    // Find rooms
    // -------------------------------------------------

    const rooms =
      await Room.find({
        department
      }).lean();

    if (!rooms.length) {
      return res.status(400).json({
        message:
          "No rooms or laboratories found for this department."
      });
    }

    // -------------------------------------------------
    // Student count
    // -------------------------------------------------

    const studentCount =
      divisionData?.studentCount ?? null;

    // -------------------------------------------------
    // Generate entries
    // -------------------------------------------------

    const entries =
      await generateTimetable({
        divisionId:
          divisionData?._id || null,

        studentCount,

        subjects,

        faculty,

        rooms
      });

    // -------------------------------------------------
    // Validate generated entries
    // -------------------------------------------------

    const validationResult =
      await validateTimetable(
        entries,
        studentCount
      );

    if (!validationResult.isValid) {
      return res.status(400).json({
        message:
          "Timetable was generated but validation failed.",
        result:
          validationResult
      });
    }

    // -------------------------------------------------
    // Save timetable as GENERATED
    // -------------------------------------------------

    const timetable =
      await Timetable.create({
        department,
        semester,

        division:
          divisionData?._id || null,

        entries,

        status: "GENERATED",

        generatedBy:
          req.user._id
      });

    // -------------------------------------------------
    // Populate generated timetable
    // -------------------------------------------------

    const populatedTimetable =
      await Timetable.findById(
        timetable._id
      )
        .populate(
          "department",
          "name code"
        )
        .populate(
          "semester",
          "name number"
        )
        .populate(
          "division",
          "name studentCount"
        )
        .populate(
          "entries.subject",
          "name code type weeklyHours practicalHours"
        )
        .populate(
          "entries.faculty",
          "name employeeId"
        )
        .populate(
          "entries.room",
          "name roomNumber type capacity"
        )
        .populate(
          "entries.timeSlot",
          "day startTime endTime slotNumber isBreak"
        );

    // -------------------------------------------------
    // Response
    // -------------------------------------------------

    res.status(201).json({
      message:
        divisionData
          ? "Division timetable generated successfully."
          : "Semester timetable generated successfully.",

      timetable:
        populatedTimetable,

      validation:
        validationResult
    });

  } catch (error) {
    console.error(
      "Generate timetable error:",
      error
    );

    res.status(500).json({
      message:
        "Failed to generate timetable.",

      error:
        error.message
    });
  }
};

// =====================================================
// EXPORTS
// =====================================================

module.exports = {
  createTimetable,
  getTimetables,
  getTimetableById,
  updateTimetable,
  updateTimetableEntry,
  deleteTimetable,
  validateTimetableById,
  publishTimetable,
  getMyTimetable,
  generateTimetableByConfig
};