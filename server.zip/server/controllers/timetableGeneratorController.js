const Department = require("../models/Department");
const Semester = require("../models/Semester");
const Division = require("../models/Division");
const Subject = require("../models/Subject");
const Faculty = require("../models/Faculty");
const Room = require("../models/Room");
const Timetable = require("../models/Timetable");
const TimeSlot = require("../models/TimeSlot");

const { generateTimetable } = require("../services/timetableGenerator");
const { validateTimetable } = require("../services/timetableValidator");


// ======================================================
// GENERATE TIMETABLE
// ======================================================

const generate = async (req, res) => {
  try {
    const { departmentId, semesterId, divisionId } = req.body;

    // --------------------------------------------------
    // Validate required fields
    // --------------------------------------------------

    if (!departmentId || !semesterId || !divisionId) {
      return res.status(400).json({
        message:
          "departmentId, semesterId and divisionId are required",
      });
    }

    // --------------------------------------------------
    // Check department
    // --------------------------------------------------

    const department = await Department.findById(departmentId);

    if (!department) {
      return res.status(404).json({
        message: "Department not found",
      });
    }

    // --------------------------------------------------
    // Check semester
    // --------------------------------------------------

    const semester = await Semester.findById(semesterId);

    if (!semester) {
      return res.status(404).json({
        message: "Semester not found",
      });
    }

    // --------------------------------------------------
    // Check division
    // --------------------------------------------------

    const division = await Division.findById(divisionId);

    if (!division) {
      return res.status(404).json({
        message: "Division not found",
      });
    }

    // --------------------------------------------------
    // Get subjects
    // --------------------------------------------------

    const subjects = await Subject.find({
      department: departmentId,
      semester: semesterId,
    }).populate("faculty");

    if (!subjects.length) {
      return res.status(400).json({
        message:
          "No subjects found for the selected department and semester",
      });
    }

    // --------------------------------------------------
    // Get faculty
    // --------------------------------------------------

    const faculty = await Faculty.find({
      department: departmentId,
    });

    if (!faculty.length) {
      return res.status(400).json({
        message:
          "No faculty found for the selected department",
      });
    }

    // --------------------------------------------------
    // Get rooms
    // --------------------------------------------------

    const rooms = await Room.find({
      $or: [
        { department: departmentId },
        { department: null },
      ],
    });

    if (!rooms.length) {
      return res.status(400).json({
        message:
          "No rooms or labs found for the selected department",
      });
    }

    // --------------------------------------------------
    // Generate timetable
    // --------------------------------------------------

    const entries = await generateTimetable({
      departmentId,
      semesterId,
      divisionId,
      subjects,
      faculty,
      rooms,
      studentCount: division.studentCount,
    });

    // --------------------------------------------------
    // Validate generated timetable
    // --------------------------------------------------

    const validation = await validateTimetable(
      entries,
      division.studentCount
    );

    if (!validation.isValid) {
      return res.status(400).json({
        message: "Generated timetable contains conflicts",
        conflicts: validation.conflicts,
      });
    }

    // --------------------------------------------------
    // Save timetable
    // --------------------------------------------------

    const timetable = await Timetable.create({
      department: departmentId,
      semester: semesterId,
      division: divisionId,
      entries,
      status: "DRAFT",
      generatedBy: req.user._id,
    });

    // --------------------------------------------------
    // Populate referenced documents
    // --------------------------------------------------

    await timetable.populate([
      {
        path: "department",
      },
      {
        path: "semester",
      },
      {
        path: "division",
      },
      {
        path: "entries.subject",
      },
      {
        path: "entries.faculty",
      },
      {
        path: "entries.room",
      },
      {
        path: "entries.timeSlot",
      },
      {
        path: "generatedBy",
        select: "name email role",
      },
    ]);

        // --------------------------------------------------
    // Get all configured time slots for timetable display
    // --------------------------------------------------

    const timeSlots = await TimeSlot.find()
      .sort({
        day: 1,
        slotNumber: 1,
      })
      .lean();

    // --------------------------------------------------
    // Send response
    // --------------------------------------------------

    return res.status(201).json({
      message: "Timetable generated successfully",
      timetable,
      timeSlots,
      conflicts: [],
    });

  } catch (error) {
    console.error("Timetable generation error:", error);

    return res.status(500).json({
      message:
        error.message || "Failed to generate timetable",
    });
  }
};


// ======================================================
// EXPORT
// ======================================================

module.exports = {
  generate,
  generateTimetable: generate,
};