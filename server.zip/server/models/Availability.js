const mongoose = require("mongoose");

const availabilitySchema = new mongoose.Schema(
  {
    resourceType: {
      type: String,
      enum: ["FACULTY", "ROOM"],
      required: true
    },

    resourceId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true
    },

    day: {
      type: String,
      enum: [
        "MONDAY",
        "TUESDAY",
        "WEDNESDAY",
        "THURSDAY",
        "FRIDAY",
        "SATURDAY"
      ],
      required: true
    },

    availableSlots: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "TimeSlot"
      }
    ]
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model("Availability", availabilitySchema);