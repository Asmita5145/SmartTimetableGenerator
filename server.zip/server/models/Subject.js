const mongoose = require("mongoose");

const subjectSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true
    },

    code: {
      type: String,
      required: true,
      trim: true,
      unique: true,
      uppercase: true
    },

    type: {
      type: String,
      enum: ["LECTURE", "PRACTICAL", "TUTORIAL"],
      required: true
    },

    department: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Department",
      required: true
    },

    semester: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Semester",
      required: true
    },

    weeklyHours: {
      type: Number,
      required: true,
      min: 1
    },

    practicalHours: {
      type: Number,
      default: 0,
      min: 0
    },

    faculty: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Faculty"
      }
    ]
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model("Subject", subjectSchema);