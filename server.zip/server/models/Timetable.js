const mongoose = require("mongoose");

const timetableSchema = new mongoose.Schema(
  {
    department: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Department",
      required: true
    },

    semester: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Semester",
      required: true
    },

    division: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Division",
      default: null
    },

    entries: [
      {
        subject: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "Subject",
          required: true
        },

        faculty: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "Faculty",
          required: true
        },

        room: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "Room",
          required: true
        },

        timeSlot: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "TimeSlot",
          required: true
        },

        durationSlots: {
          type: Number,
          enum: [1, 2],
          default: 1
        }
      }
    ],

    status: {
      type: String,
      enum: ["DRAFT", "GENERATED", "PUBLISHED"],
      default: "DRAFT"
    },

    generatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    }
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model("Timetable", timetableSchema);