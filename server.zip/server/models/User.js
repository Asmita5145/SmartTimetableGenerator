const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true
    },

    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true
    },

    password: {
      type: String,
      required: true
    },

    role: {
      type: String,
      enum: ["ADMIN", "FACULTY", "STUDENT"],
      default: "STUDENT"
    },

    // Academic assignment for students
    department: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Department",
      default: null
    },

    semester: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Semester",
      default: null
    },

    // Optional because not every semester/branch needs divisions
    division: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Division",
      default: null
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model("User", userSchema);