const express = require("express");

const {
  getMasterTimetables,
  getMasterTimetableById,
  generateMaster,
  getBatches,
} = require("../controllers/masterTimetableController");

const {
  protect,
  adminOnly,
} = require("../middleware/authMiddleware");

const router =
  express.Router();

router.get(
  "/batches",
  protect,
  adminOnly,
  getBatches
);

router.post(
  "/generate",
  protect,
  adminOnly,
  generateMaster
);

router.get(
  "/",
  protect,
  adminOnly,
  getMasterTimetables
);

router.get(
  "/:id",
  protect,
  adminOnly,
  getMasterTimetableById
);

module.exports = router;