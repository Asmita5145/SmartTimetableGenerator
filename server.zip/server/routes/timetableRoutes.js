const express = require("express");

const {
  createTimetable,
  getTimetables,
  getTimetableById,
  updateTimetable,
  updateTimetableEntry,
  deleteTimetable,
  validateTimetableById,
  publishTimetable,
  getMyTimetable,
  generateTimetableByConfig
} = require("../controllers/timetableController");

const {
  protect,
  adminOnly
} = require("../middleware/authMiddleware");

const router = express.Router();

router.post(
  "/",
  protect,
  adminOnly,
  createTimetable
);

router.get(
  "/",
  protect,
  adminOnly,
  getTimetables
);

router.post(
  "/generate",
  protect,
  adminOnly,
  generateTimetableByConfig
);

router.post(
  "/:id/validate",
  protect,
  adminOnly,
  validateTimetableById
);

router.post(
  "/:id/publish",
  protect,
  adminOnly,
  publishTimetable
);

router.get(
  "/student/my",
  protect,
  getMyTimetable
);

router.get(
  "/:id",
  protect,
  adminOnly,
  getTimetableById
);

router.put(
  "/:id/entries/:entryId",
  protect,
  adminOnly,
  updateTimetableEntry
);

router.put(
  "/:id",
  protect,
  adminOnly,
  updateTimetable
);

router.delete(
  "/:id",
  protect,
  adminOnly,
  deleteTimetable
);

module.exports = router;