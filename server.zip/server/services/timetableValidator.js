
const TimeSlot = require("../models/TimeSlot");
const Room = require("../models/Room");
const Availability = require("../models/Availability");
const Subject = require("../models/Subject");

const idOf = (value) => {
  if (!value) return null;
  return String(value._id || value);
};

const doSlotsOverlap = (slot1, duration1, slot2, duration2) => {
  if (!slot1 || !slot2 || slot1.day !== slot2.day) {
    return false;
  }

  const start1 = slot1.slotNumber;
  const end1 = start1 + duration1 - 1;
  const start2 = slot2.slotNumber;
  const end2 = start2 + duration2 - 1;

  return start1 <= end2 && start2 <= end1;
};

const validateTimetable = async (input, suppliedStudentCount) => {
  // Support both validateTimetable(entries, studentCount)
  // and validateTimetable(timetable).
  const isTimetableDocument = !Array.isArray(input) && input != null;

  const entries = Array.isArray(input)
    ? input
    : input?.entries || [];

  const studentCount =
    suppliedStudentCount ??
    input?.division?.studentCount;

  const conflicts = [];

  if (!entries.length) {
    return {
      isValid: false,
      conflicts: [
        {
          type: "EMPTY_TIMETABLE",
          message: "The timetable has no scheduled entries."
        }
      ]
    };
  }

  // 1. Load starting slots and all slots on their days.
  const startSlotIds = [
    ...new Set(entries.map((entry) => idOf(entry.timeSlot)).filter(Boolean))
  ];

  const startSlots = await TimeSlot.find({
    _id: { $in: startSlotIds }
  }).lean();

  const startSlotMap = new Map(
    startSlots.map((slot) => [String(slot._id), slot])
  );

  const days = [...new Set(startSlots.map((slot) => slot.day))];

  const allSlots = await TimeSlot.find({
    day: { $in: days }
  }).lean();

  const slotsByDayAndNumber = new Map();

  for (const slot of allSlots) {
    slotsByDayAndNumber.set(
      `${slot.day}_${slot.slotNumber}`,
      slot
    );
  }

  // 2. Load rooms and subjects.
  const roomIds = [
    ...new Set(entries.map((entry) => idOf(entry.room)).filter(Boolean))
  ];

  const subjectIds = [
    ...new Set(entries.map((entry) => idOf(entry.subject)).filter(Boolean))
  ];

  const [rooms, subjects] = await Promise.all([
    Room.find({ _id: { $in: roomIds } }).lean(),
    Subject.find({ _id: { $in: subjectIds } }).lean()
  ]);

  const roomMap = new Map(
    rooms.map((room) => [String(room._id), room])
  );

  const subjectMap = new Map(
    subjects.map((subject) => [String(subject._id), subject])
  );

  // 3. Load availability records for referenced resources.
  const facultyIds = [
    ...new Set(entries.map((entry) => idOf(entry.faculty)).filter(Boolean))
  ];

  const [facultyAvailability, roomAvailability] = await Promise.all([
    Availability.find({
      resourceType: "FACULTY",
      resourceId: { $in: facultyIds }
    }).lean(),

    Availability.find({
      resourceType: "ROOM",
      resourceId: { $in: roomIds }
    }).lean()
  ]);

  // Match the generator's rule:
  // no record for a resource/day means unrestricted availability;
  // otherwise every occupied slot must be explicitly available.
  const isAvailable = (records, resourceId, slot) => {
    const recordsForDay = records.filter(
      (record) =>
        String(record.resourceId) === String(resourceId) &&
        record.day === slot.day
    );

    if (!recordsForDay.length) {
      return true;
    }

    const allowedSlotIds = new Set(
      recordsForDay.flatMap((record) =>
        record.availableSlots.map(String)
      )
    );

    return allowedSlotIds.has(String(slot._id));
  };

  // 4. Validate each entry.
  const normalizedEntries = [];

  for (let i = 0; i < entries.length; i += 1) {
    const entry = entries[i];
    const label = `Entry ${i + 1}`;

    const subjectId = idOf(entry.subject);
    const roomId = idOf(entry.room);
    const facultyId = idOf(entry.faculty);
    const startSlotId = idOf(entry.timeSlot);

    const startSlot = startSlotMap.get(startSlotId);
    const room = roomMap.get(roomId);
    const subject = subjectMap.get(subjectId);

    const duration = Number(entry.durationSlots || 1);

    if (!startSlot) {
      conflicts.push({
        type: "INVALID_TIME_SLOT",
        message: `${label}: starting time slot was not found.`
      });
      continue;
    }

    if (startSlot.isBreak) {
      conflicts.push({
        type: "BREAK_SLOT",
        message: `${label}: a class cannot start during a break.`
      });
    }

    if (!room) {
      conflicts.push({
        type: "INVALID_ROOM",
        message: `${label}: room was not found.`
      });
    }

    if (!subject) {
      conflicts.push({
        type: "INVALID_SUBJECT",
        message: `${label}: subject was not found.`
      });
    }

    if (!facultyId) {
      conflicts.push({
        type: "INVALID_FACULTY",
        message: `${label}: faculty is missing.`
      });
    }

    if (![1, 2].includes(duration)) {
      conflicts.push({
        type: "INVALID_DURATION",
        message: `${label}: duration must be one or two slots.`
      });
      continue;
    }

    if (!subject || !room) {
      continue;
    }

    if (
      subject.type === "PRACTICAL" &&
      duration !== 2
    ) {
      conflicts.push({
        type: "SUBJECT_DURATION",
        message: `Practical "${subject.name}" must occupy two slots.`
      });
    }

    if (
      subject.type !== "PRACTICAL" &&
      duration !== 1
    ) {
      conflicts.push({
        type: "SUBJECT_DURATION",
        message: `${subject.type} "${subject.name}" must occupy one slot.`
      });
    }

    if (
      subject.type === "PRACTICAL" &&
      room.type !== "LAB"
    ) {
      conflicts.push({
        type: "PRACTICAL_ROOM",
        message: `Practical "${subject.name}" must use a laboratory.`
      });
    }

    if (
      subject.type !== "PRACTICAL" &&
      room.type !== "CLASSROOM"
    ) {
      conflicts.push({
        type: "LECTURE_ROOM",
        message: `${subject.type} "${subject.name}" must use a classroom.`
      });
    }

    if (
      studentCount != null &&
      room.capacity < studentCount
    ) {
      conflicts.push({
        type: "ROOM_CAPACITY",
        message: `Room ${room.roomNumber} has capacity ${room.capacity}, but the division has ${studentCount} students.`
      });
    }

    const occupiedSlots = [];

    for (let offset = 0; offset < duration; offset += 1) {
      const slot = slotsByDayAndNumber.get(
        `${startSlot.day}_${startSlot.slotNumber + offset}`
      );

      if (!slot) {
        conflicts.push({
          type: "INVALID_DURATION",
          message: `${label}: required consecutive slot ${startSlot.slotNumber + offset} does not exist.`
        });
        break;
      }

      if (slot.isBreak) {
        conflicts.push({
          type: "BREAK_SLOT",
          message: `${label}: the session crosses a break.`
        });
        break;
      }

      occupiedSlots.push(slot);
    }

    if (occupiedSlots.length !== duration) {
      continue;
    }

    for (const slot of occupiedSlots) {
      if (
        facultyId &&
        !isAvailable(facultyAvailability, facultyId, slot)
      ) {
        conflicts.push({
          type: "FACULTY_UNAVAILABLE",
          message: `${label}: faculty is unavailable on ${slot.day}, slot ${slot.slotNumber}.`
        });
      }

      if (!isAvailable(roomAvailability, roomId, slot)) {
        conflicts.push({
          type: "ROOM_UNAVAILABLE",
          message: `${label}: room is unavailable on ${slot.day}, slot ${slot.slotNumber}.`
        });
      }
    }

    normalizedEntries.push({
      entry,
      startSlot,
      duration,
      facultyId,
      roomId,
      occupiedSlots
    });
  }

  // 5. Detect overlapping sessions.
  // Entries in one timetable are assumed to belong to its one division.
  for (let i = 0; i < normalizedEntries.length; i += 1) {
    const current = normalizedEntries[i];

    for (let j = i + 1; j < normalizedEntries.length; j += 1) {
      const other = normalizedEntries[j];

      if (
        !doSlotsOverlap(
          current.startSlot,
          current.duration,
          other.startSlot,
          other.duration
        )
      ) {
        continue;
      }

      if (
        current.facultyId &&
        current.facultyId === other.facultyId
      ) {
        conflicts.push({
          type: "FACULTY_CONFLICT",
          message: `Entries ${i + 1} and ${j + 1} use the same faculty member at overlapping times.`
        });
      }

      if (current.roomId === other.roomId) {
        conflicts.push({
          type: "ROOM_CONFLICT",
          message: `Entries ${i + 1} and ${j + 1} use the same room at overlapping times.`
        });
      }

      conflicts.push({
        type: "DIVISION_CONFLICT",
        message: `Entries ${i + 1} and ${j + 1} overlap for the same division.`
      });
    }
  }

  return {
    isValid: conflicts.length === 0,
    conflicts
  };
};

module.exports = {
  validateTimetable,
  doSlotsOverlap
};
